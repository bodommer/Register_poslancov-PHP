<footer>
  <p>2017 Copyright Andrej Jurčo</p>
</footer>
</body>
</html>
