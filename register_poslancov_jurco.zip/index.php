<?php
$nazov = 'Domov';
include('funkcie.php');
include('hlavicka.php');
?>
<section>
  <h3>Vitajte na stránkach centrálneho registra poslancov!</h3>
  <p>Pokiaľ chcete vyhľadať záznamy o niektorom z poslancov, môžete tak spraviť v sekcii <a href="vyhladavanie.php">Vyhľadávanie</a>.</p>
  <p>Pokiaľ ste poslanec a chcete aktualizovať svoje aktivity, navštíve sekciu <a href="administracia.php">Administrácia</a></p>
</section>
<?php
include('pata.php')
?>
