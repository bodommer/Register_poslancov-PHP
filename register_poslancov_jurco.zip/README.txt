projekt je dostupny na adrese: http://www.st.fmph.uniba.sk/~jurco15/Register%20poslancov/index.php

pre administraciu sa mozete prihlasit do nasledujucich uctov:
Jozef Mrkva 	heslo: mrkva23
Jan Kratky	heslo: kratky22
Peter Stastny 	heslo: stastko777
Lea Rychla	heslo: lea123

Logo stranky je pouzite len ako nahodne najdeny obrazok v pocitaci autora.

Pre import databazy a suborov treba pouzit subor EXPORT_DATABAZY.sql

Pridavanie novych pouzivatelov je mozne iba cez spravu databazy - pocet poslancov
je koniec-koncov konecny a nie je ptorebne nechat si kohokolvek vytvorit poslanecky
ucet.

Vo vyhladavani sa po kliknuti na meno poslanca v tabulke otvori nova tabulka, ktora
zobrazi vsetky zaznamy s nim spojene v tabulke casy. Mazanie uzivatelov je nastavene 
na kaskadovite - skusanie sa neodporuca (zdlhavy proces nahadzovania udajov naspat).